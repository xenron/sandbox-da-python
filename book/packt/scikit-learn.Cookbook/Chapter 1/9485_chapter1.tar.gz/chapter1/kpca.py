# IPython log file


from __future__ import division
import numpy as np
import numpy as np
A = np.random.multivariate_normal([2, 2], [[1, .5], [.5, 1]], 10)
A
